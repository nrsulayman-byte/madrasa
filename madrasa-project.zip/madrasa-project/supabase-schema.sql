-- হামিদুল উলুম মাদ্রাসা — Supabase ডেটাবেজ স্কিমা
-- Supabase Dashboard > SQL Editor এ এই পুরো ফাইলটা পেস্ট করে Run চাপুন

-- ১) প্রোফাইল টেবিল (auth.users এর সাথে যুক্ত)
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  phone text,
  email text,
  avatar_url text,
  role text default 'student' check (role in ('student','admin')),
  created_at timestamp with time zone default now()
);

-- ২) ভর্তি আবেদন / ছাত্র তথ্য
create table admissions (
  id uuid default gen_random_uuid() primary key,
  student_id uuid references profiles(id),
  full_name text not null,
  date_of_birth date,
  department text,
  father_name text,
  mother_name text,
  guardian_phone text,
  address text,
  birth_cert_url text,
  photo_url text,
  status text default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamp with time zone default now()
);

-- ৩) বেতন
create table fees (
  id uuid default gen_random_uuid() primary key,
  student_id uuid references profiles(id),
  month text not null,
  amount numeric not null,
  method text check (method in ('cash','bkash','nagad')),
  status text default 'due' check (status in ('due','paid')),
  paid_at timestamp with time zone
);

-- ৪) অভিযোগ
create table complaints (
  id uuid default gen_random_uuid() primary key,
  student_id uuid references profiles(id),
  subject text,
  details text,
  status text default 'pending' check (status in ('pending','resolved')),
  created_at timestamp with time zone default now()
);

-- ৫) নোটিশ
create table notices (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  body text,
  created_at timestamp with time zone default now()
);

-- Row Level Security চালু করা (নিরাপত্তার জন্য জরুরি)
alter table profiles enable row level security;
alter table admissions enable row level security;
alter table fees enable row level security;
alter table complaints enable row level security;
alter table notices enable row level security;

-- ইউজার শুধু নিজের প্রোফাইল দেখতে/পরিবর্তন করতে পারবে
create policy "নিজের প্রোফাইল দেখা যাবে" on profiles for select using (auth.uid() = id);
create policy "নিজের প্রোফাইল পরিবর্তন করা যাবে" on profiles for update using (auth.uid() = id);

-- ইউজার নিজের ভর্তি আবেদন/বেতন/অভিযোগ দেখতে পারবে, নতুন যোগ করতে পারবে
create policy "নিজের আবেদন দেখা" on admissions for select using (auth.uid() = student_id);
create policy "নতুন আবেদন যোগ" on admissions for insert with check (auth.uid() = student_id);
create policy "নিজের বেতন দেখা" on fees for select using (auth.uid() = student_id);
create policy "নিজের অভিযোগ দেখা" on complaints for select using (auth.uid() = student_id);
create policy "নতুন অভিযোগ যোগ" on complaints for insert with check (auth.uid() = student_id);

-- সবাই নোটিশ দেখতে পারবে
create policy "নোটিশ সবাই দেখতে পারবে" on notices for select using (true);

-- এডমিনরা সবকিছু দেখতে/পরিবর্তন করতে পারবে
create policy "এডমিন সব প্রোফাইল দেখবে" on profiles for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
create policy "এডমিন সব আবেদন দেখবে/পরিবর্তন করবে" on admissions for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
create policy "এডমিন সব বেতন দেখবে/পরিবর্তন করবে" on fees for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
create policy "এডমিন সব অভিযোগ দেখবে/পরিবর্তন করবে" on complaints for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
create policy "এডমিন নোটিশ যোগ/পরিবর্তন করবে" on notices for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
