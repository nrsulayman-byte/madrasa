# হামিদুল উলুম মাদ্রাসা — অ্যাপ প্রজেক্ট

এই ফোল্ডারে আছে:
- `index.html` — লগইন/সাইনআপ পেজ + ছাত্র ড্যাশবোর্ড (Supabase Auth কানেক্টেড)
- `admin.html` — এডমিন প্যানেল
- `admission.html` — ভর্তি আবেদন ফরম
- `complaint.html` — অভিযোগ কেন্দ্র
- `supabase-schema.sql` — ডেটাবেজ টেবিল তৈরির SQL স্ক্রিপ্ট

Supabase Project URL ও Publishable Key ইতিমধ্যে `index.html`-এ বসানো আছে, তাই আলাদাভাবে কিছু করতে হবে না।

## ধাপ ১: Supabase ডেটাবেজ তৈরি (যদি এখনো না করে থাকেন)
Supabase Dashboard > SQL Editor এ গিয়ে `supabase-schema.sql` ফাইলের পুরো কোড পেস্ট করে **Run** চাপুন। এতে সব টেবিল (profiles, admissions, fees, complaints, notices) তৈরি হয়ে যাবে।

## ধাপ ২: GitHub-এ রিপোজিটরি তৈরি
1. github.com এ লগইন করুন (অ্যাকাউন্ট না থাকলে ফ্রি তৈরি করুন)
2. উপরে ডানদিকে **+** আইকনে ক্লিক করে **New repository** বাছুন
3. নাম দিন, যেমন: `hamidul-ulum-madrasa`
4. **Public** রাখুন (GitHub Pages ফ্রিতে চালাতে Public থাকা সুবিধাজনক)
5. **Create repository** চাপুন

## ধাপ ৩: ফাইল আপলোড
রিপোজিটরি পেজে **Add file > Upload files** চাপুন, এই ফোল্ডারের সব ফাইল (index.html, admin.html, admission.html, complaint.html, supabase-schema.sql) টেনে এনে (drag & drop) আপলোড করুন, তারপর **Commit changes** চাপুন।

## ধাপ ৪: GitHub Pages দিয়ে লাইভ করা (ফ্রি হোস্টিং)
1. রিপোজিটরির **Settings** ট্যাবে যান
2. বামপাশের মেনুতে **Pages** এ ক্লিক করুন
3. **Source** এ `main` ব্রাঞ্চ বাছুন, ফোল্ডার `/ (root)` রেখে **Save** চাপুন
4. ১-২ মিনিট পর একটা লিংক পাবেন, যেমন: `https://your-username.github.io/hamidul-ulum-madrasa/`
5. এই লিংকই আপনার অ্যাপের আসল লিংক — এখান থেকে যে কেউ লগইন/সাইনআপ করতে পারবে, আর ডেটা সরাসরি আপনার Supabase-এ যাবে

## পরবর্তী ধাপ (এখনো বাকি)
- বেতন পরিশোধ (নগদ/বিকাশ) ফ্লো Supabase-এর সাথে সংযুক্ত করা
- ভর্তি ফরম ও অভিযোগ ফরম থেকে সত্যিকারের ডেটাবেজে সেভ করা (এখনো এগুলো শুধু ডেমো অ্যালার্ট দেখায়)
- এডমিন প্যানেল থেকে আসল ডেটা লোড/এডিট করা
- মোবাইল নম্বর দিয়ে লগইন (SMS প্রোভাইডার লাগবে)
- ছবি আপলোড (জন্ম নিবন্ধন, পাসপোর্ট ছবি) Supabase Storage-এ সেভ করা

এই কাজগুলো একটার পর একটা এগিয়ে নিলে ভালো হয় — কোনটা আগে করতে চান বলুন।
